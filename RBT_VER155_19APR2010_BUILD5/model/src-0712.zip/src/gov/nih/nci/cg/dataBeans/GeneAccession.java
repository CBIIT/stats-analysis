package gov.nih.nci.cg.dataBeans;

import java.io.Serializable;

/**
 * User: Ram Bhattaru <BR>
 * Date: Apr 13, 2006 <BR>
 * Version: 1.0 <BR>
 */
public class GeneAccession implements Serializable {
    public final static String GENE_SYMBOL = "geneSymbol";
    public final static String ACCESSION = "accession";

    private String accession;
    private String geneSymbol;
}
