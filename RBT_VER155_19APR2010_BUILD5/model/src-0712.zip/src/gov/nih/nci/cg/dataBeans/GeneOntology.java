package gov.nih.nci.cg.dataBeans;

import java.io.Serializable;

/**
 * User: Ram Bhattaru <BR>
 * Date: Apr 12, 2006 <BR>
 * Version: 1.0 <BR>
 */
public class GeneOntology implements Serializable {
    public final static String GO_ID = "goID";
    public final static String GENE_SYMBOL = "geneSymbol";
    private String goID;
    private String geneSymbol;

    public String getGoID() {
        return goID;
    }

    public void setGoID(String goID) {
        this.goID = goID;
    }

    public String getGeneSymbol() {
        return geneSymbol;
    }

    public void setGeneSymbol(String geneSymbol) {
        this.geneSymbol = geneSymbol;
    }

    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        final GeneOntology that = (GeneOntology) o;

        if (geneSymbol != null ? !geneSymbol.equals(that.geneSymbol) : that.geneSymbol != null) return false;
        if (goID != null ? !goID.equals(that.goID) : that.goID != null) return false;

        return true;
    }

    public int hashCode() {
        int result;
        result = (goID != null ? goID.hashCode() : 0);
        result = 29 * result + (geneSymbol != null ? geneSymbol.hashCode() : 0);
        return result;
    }

}
