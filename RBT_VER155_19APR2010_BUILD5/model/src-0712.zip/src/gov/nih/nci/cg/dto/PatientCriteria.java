package gov.nih.nci.cg.dto;

import gov.nih.nci.cg.findings.TimeCourse;

import java.util.Collection;

/**
 * User: Ram Bhattaru <BR>
 * Date: Apr 27, 2006 <BR>
 * Version: 1.0 <BR>
 */

public class PatientCriteria extends StudyParticipantCriteria {

    private Collection<String> studySubjectIdentifiers;
    private Collection<TimeCourse> timeCourse;

    public PatientCriteria(){}

    public Collection<String> getStudySubjectIdentifiers() {
        return studySubjectIdentifiers;
    }

    public void setStudySubjectIdentifiers(Collection<String> studySubjectIdentifiers) {
        this.studySubjectIdentifiers = studySubjectIdentifiers;
    }

    public Collection<TimeCourse> getTimeCourse() {
        return timeCourse;
    }

    public void setTimeCourse(Collection<TimeCourse> timeCourse) {
        this.timeCourse = timeCourse;
    }

}