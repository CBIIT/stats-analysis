package gov.nih.nci.cg.enums;

/**
 * @version 1.0
 * @created 04-Apr-2006 3:09:06 AM
 */
public enum OperatorType {
	AND,
	EQ,
	GT,
	LT,
	OR
}