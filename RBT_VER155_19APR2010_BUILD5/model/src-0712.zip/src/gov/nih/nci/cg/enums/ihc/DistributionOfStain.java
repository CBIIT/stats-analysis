package gov.nih.nci.cg.enums.ihc;

/**
 * none, homogenous, hetrogenous, unifocal, multifocal, unevaluable
 *
 * User: Ram Bhattaru <BR>
 * Date: Mar 29, 2006 <BR>
 * Version: 1.0 <BR>
 */

public enum DistributionOfStain {
	hetrogenous,
	homogenous,
	multifocal,
	none,
	unevaluable,
	unifocal
}