package gov.nih.nci.cg.enums.ihc;

/**
  * cytoplasm, membrane, membrane_and_cytoplasm, none, nuclear_and_cytoplasm,
  * nucleus
  *
  * User: Ram Bhattaru <BR>
  * Date: Mar 29, 2006 <BR>
  * Version: 1.0 <BR>
 */
public enum LocalizationOfStain {
	cytoplasm,
	membrane,
	membrane_and_cytoplasm,
	none,
	nuclear_and_cytoplasm,
	nucleus
}