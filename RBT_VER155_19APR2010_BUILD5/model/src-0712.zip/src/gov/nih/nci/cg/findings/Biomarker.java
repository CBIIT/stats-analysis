package gov.nih.nci.cg.findings;

/**
 * User: Ram Bhattaru <BR>
 * Date: Mar 30, 2006 <BR>
 * Version: 1.0 <BR>
 */
public abstract class Biomarker {

	public Biomarker(){

	}


}