package gov.nih.nci.cg.findings;

/**
 * User: Ram Bhattaru <BR>
 * Date: Mar 19, 2006 <BR>
 * Version: 1.0 <BR>
 */

public class Cytoband {

	private String end;
	private String start;

	public Cytoband(){

	}

	public void finalize() throws Throwable {

	}

}