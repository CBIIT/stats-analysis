package gov.nih.nci.cg.findings;

/**
 * User: Ram Bhattaru <BR>
 * Date: Mar 30, 2006 <BR>
 * Version: 1.0 <BR>
 */
public class FISHFinding extends SpecimenBasedMolecularFinding {
    public final static String GENE_BASED_BIOMARKER = "geneBasedBiomarker";
    public final static String CNA_STATUS = "cnaStatus";
    public final static String RATIO = "ratio";
    public final static String REFERENCE_NAME="referenceName";

    private Long id;
    private Double biomarkerNuclei;
	private CopyNumberAbnomalityStatus cnaStatus;
	private Double ratio;
	private String referenceName;
	private Double referenceNuclei;
	private GeneBasedBiomarker geneBasedBiomarker;
    //private Specimen specimen;

    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        final FISHFinding that = (FISHFinding) o;

        if (id != null ? !id.equals(that.id) : that.id != null) return false;

        return true;
    }

    public int hashCode() {
        return (id != null ? id.hashCode() : 0);
    }

    public FISHFinding(){

	}

    /*
    public Specimen getSpecimen() {
        return specimen;
    }

    public void setSpecimen(Specimen specimen) {
        this.specimen = specimen;
    }
*/
    public Long getId() {
        return id;
    }

    private  void setId(Long id) {
        this.id = id;
    }

    public Double getBiomarkerNuclei() {
        return biomarkerNuclei;
    }

    public CopyNumberAbnomalityStatus getCnaStatus() {
        return cnaStatus;
    }

    public Double getRatio() {
        return ratio;
    }

    public String getReferenceName() {
        return referenceName;
    }

    public Double getReferenceNuclei() {
        return referenceNuclei;
    }

    public GeneBasedBiomarker getGeneBasedBiomarker() {
            return geneBasedBiomarker;
    }

    private void setBiomarkerNuclei(Double biomarkerNuclei) {
        this.biomarkerNuclei = biomarkerNuclei;
    }

    public void setCnaStatus(CopyNumberAbnomalityStatus cnaStatus) {
        this.cnaStatus = cnaStatus;
    }

    public void setRatio(Double ratio) {
        this.ratio = ratio;
    }

    public void setReferenceName(String reference) {
        this.referenceName= reference;
    }

    public void setReferenceNuclei(Double referenceNuclei) {
        this.referenceNuclei = referenceNuclei;
    }

    public void setGeneBasedBiomarker(GeneBasedBiomarker geneBasedBiomarker) {
        this.geneBasedBiomarker = geneBasedBiomarker;
    }
}