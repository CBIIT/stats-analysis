package gov.nih.nci.cg.findings;

/**
 * User: Ram Bhattaru <BR>
 * Date: Apr 4, 2006 <BR>
 * Version: 1.0 <BR>
 */
public class LocusLink extends GeneIdentifier{
    public LocusLink(String value) {
        super(value);
    }

    public LocusLink() {
    }

}
