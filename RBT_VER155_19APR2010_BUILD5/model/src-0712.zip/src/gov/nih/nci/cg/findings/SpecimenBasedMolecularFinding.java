package gov.nih.nci.cg.findings;

/**
 * User: Ram Bhattaru <BR>
 * Date: Mar 19, 2006 <BR>
 * Version: 1.0 <BR>
 */

public abstract class SpecimenBasedMolecularFinding {

    protected Specimen specimen;

    public SpecimenBasedMolecularFinding(){

    }

    public Specimen getSpecimen() {
        return specimen;
    }

    public void setSpecimen(Specimen specimen) {
        this.specimen = specimen;
    }
}