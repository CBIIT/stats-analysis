package gov.nih.nci.cg.findings;

import gov.nih.nci.cg.findings.Specimen;

import java.util.Date;
import java.util.Collection;

/**
 * The treatment arm and other specifics regarding the participation of the
 * Subject to a particular Study.
 *
  * User: Ram Bhattaru <BR>
  * Date: Mar 30, 2006 <BR>
  * Version: 1.0 <BR>
 */
public class StudyParticipant {

        private String administrativeGenderCode;
        private Integer ageAtDiagnosis;
        private Integer ageAtEnrollment;
        private Integer ageAtDeath;
        private String ethnicGroupCode;
        private String institutionName;
        private Integer daysOnStudy;
        private String raceCode;
        private Boolean offStudy;
        private String studyPartcipantIdentifier;
        private Boolean survivalStatus;
        public  Specimen specimens;

    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        final StudyParticipant that = (StudyParticipant) o;

        if (studyPartcipantIdentifier != null ? !studyPartcipantIdentifier.equals(that.studyPartcipantIdentifier) : that.studyPartcipantIdentifier != null)
            return false;

        return true;
    }

    public int hashCode() {
        return (studyPartcipantIdentifier != null ? studyPartcipantIdentifier.hashCode() : 0);
    }

    /****  TODO: associate the belolw objects
        public Histology histology;
        public StudyTimePoint studyTimePoints;
        public Activity activities;
        ******/

    public StudyParticipant(){

    }

    public String getAdministrativeGenderCode() {
        return administrativeGenderCode;
    }

    public void setAdministrativeGenderCode(String administrativeGenderCode) {
        this.administrativeGenderCode = administrativeGenderCode;
    }

    public Integer getAgeAtDiagnosis() {
        return ageAtDiagnosis;
    }

    public void setAgeAtDiagnosis(Integer ageAtDiagnosis) {
        this.ageAtDiagnosis = ageAtDiagnosis;
    }

    public Integer getAgeAtEnrollment() {
        return ageAtEnrollment;
    }

    public void setAgeAtEnrollment(Integer ageAtEnrollment) {
        this.ageAtEnrollment = ageAtEnrollment;
    }

    public Integer getAgeAtDeath() {
        return ageAtDeath;
    }

    public void setAgeAtDeath(Integer ageAtDeath) {
        this.ageAtDeath = ageAtDeath;
    }

    public String getEthnicGroupCode() {
        return ethnicGroupCode;
    }

    public void setEthnicGroupCode(String ethnicGroupCode) {
        this.ethnicGroupCode = ethnicGroupCode;
    }

    public String getInstitutionName() {
        return institutionName;
    }

    public void setInstitutionName(String institutionName) {
        this.institutionName = institutionName;
    }

    public Integer getDaysOnStudy() {
        return daysOnStudy;
    }

    public void setDaysOnStudy(Integer daysOnStudy) {
        this.daysOnStudy = daysOnStudy;
    }

    public String getRaceCode() {
        return raceCode;
    }

    public void setRaceCode(String raceCode) {
        this.raceCode = raceCode;
    }

    public Boolean getOffStudy() {
        return offStudy;
    }

    public void setOffStudy(Boolean offStudy) {
        this.offStudy = offStudy;
    }

    public String getStudyPartcipantIdentifier() {
        return studyPartcipantIdentifier;
    }

    public void setStudyPartcipantIdentifier(String studyPartcipantIdentifier) {
        this.studyPartcipantIdentifier = studyPartcipantIdentifier;
    }

    public Boolean getSurvivalStatus() {
        return survivalStatus;
    }

    public void setSurvivalStatus(Boolean survivalStatus) {
        this.survivalStatus = survivalStatus;
    }

    public Specimen getSpecimens() {
        return specimens;
    }

    public void setSpecimens(Specimen specimens) {
        this.specimens = specimens;
    }
}
