package gov.nih.nci.cg.findings.handlers;

import gov.nih.nci.cg.enums.OperatorType;
import gov.nih.nci.cg.dto.AnnotationCriteria;
import gov.nih.nci.cg.dataBeans.GeneOntology;
import gov.nih.nci.cg.dataBeans.GenePathway;
import gov.nih.nci.cg.findings.*;

import java.util.*;

import org.hibernate.Session;
import org.hibernate.Criteria;
import org.hibernate.criterion.Restrictions;
import org.hibernate.criterion.Property;

/**
 * User: Ram Bhattaru <BR>
 * Date: Apr 12, 2006 <BR>
 * Version: 1.0 <BR>
 */
public class AnnotationCriteriaHandler {
   
    private OperatorType operatorType;

    /**
     * This method converts each of the annotations in to GeneSymbols
     *
     * @param annotCrit
     * @param session
     * @return Set of GeneSymbols
     */

    public Set<GeneSymbol> handle(AnnotationCriteria annotCrit,  Session session) {
        Set<GeneSymbol> allGeneSymbolObjs = new HashSet();
        Collection<GeneSymbol> geGeneSymbols = null;
        Collection<GeneSymbol> goGeneSymbolsObjs = null;
        Collection<GeneSymbol> pwgeneSymbolsObjs = null;
        OperatorType opType = annotCrit.getOperatorType();
        if (opType == null) opType = OperatorType.OR;

        // convert GeneIdentifiers in to GeneSymbols
        if (annotCrit.getGeneIdentifiers() != null && annotCrit.getGeneIdentifiers().size() > 0) {
            geGeneSymbols = handleGeneIdentifiers(annotCrit, session);
        }

        // convert GOIDs in to GeneSymbols
        if (annotCrit.getGeneOntologyIDs() != null) {
             goGeneSymbolsObjs = convertGOIDsToGeneSymbols(annotCrit.getGeneOntologyIDs(), session);
        }

        // convert Pathways in to GeneSymbols
        if (annotCrit.getPathways() != null) {
            pwgeneSymbolsObjs = convertPathwaysToGeneSymbols(annotCrit.getPathways() , session);
        }
        if (opType == operatorType.OR) { // take Union of all GeneSymbols
            Set<GeneSymbol> unionOfAllGeneSymbols = getAllGeneSymbols(geGeneSymbols, goGeneSymbolsObjs, pwgeneSymbolsObjs);
            allGeneSymbolObjs.addAll(unionOfAllGeneSymbols);
        } else {  // // take intersection of all GeneSymbols
            Set<GeneSymbol> intersectionGS = getCommonGeneSymbols(geGeneSymbols, goGeneSymbolsObjs, pwgeneSymbolsObjs);
            allGeneSymbolObjs.addAll(intersectionGS);
        }
        return allGeneSymbolObjs;
    }

    public static Set<GeneSymbol> getAllGeneSymbols(Collection<GeneSymbol> geGeneSymbols, Collection<GeneSymbol> goGeneSymbolsObjs, Collection<GeneSymbol> pwgeneSymbolsObjs) {
        Set<GeneSymbol> unionOfAllGeneSymbols = new HashSet();
        if (geGeneSymbols != null && geGeneSymbols.size() > 0)
           unionOfAllGeneSymbols.addAll(geGeneSymbols);
        if (goGeneSymbolsObjs != null && goGeneSymbolsObjs.size() > 0)
           unionOfAllGeneSymbols.addAll(goGeneSymbolsObjs);
        if (pwgeneSymbolsObjs != null && pwgeneSymbolsObjs.size() > 0)
            unionOfAllGeneSymbols.addAll(pwgeneSymbolsObjs);

        return unionOfAllGeneSymbols;
    }

    /*
    private Set<GeneSymbol> getCommonGeneSymbols(Collection<GeneSymbol> geGeneSymbols, Collection<GeneSymbol> goGeneSymbolsObjs, Collection<GeneSymbol> pwgeneSymbolsObjs) {
        Set<GeneSymbol> intersectionGS = new HashSet<GeneSymbol>();

        // if geneIdentifiers were specified in the initial AnnotationCriteria and nothing got selected
        if (geGeneSymbols != null && (geGeneSymbols.size() == 0)) return intersectionGS;

        intersectionGS.addAll(geGeneSymbols);

        if (goGeneSymbolsObjs != null) {  // means goIDs were specified in the initial AnnotationCriteria
            if (intersectionGS.size() == 0) { // means no GeneIdentifiers were specified in the AnnotationCriteria
                intersectionGS.addAll(goGeneSymbolsObjs);
            }
            else { // means // take intersection of goGeneSymbolsObjs & geGeneSymbols
                Iterator<GeneSymbol> intersectionIter =  intersectionGS.iterator();
                while (intersectionIter.hasNext()) {
                    GeneSymbol geneSymbol = intersectionIter.next();
                    if (! goGeneSymbolsObjs.contains(geneSymbol)) {
                        // remove from intersectionGS list
                        intersectionGS.remove(geneSymbol);
                    }
                }
            }
        }

        if (pwgeneSymbolsObjs != null) { // means pathways were specified in the initial AnnotationCriteria
             if (intersectionGS.size() > 0) {
                // take intersection of goGeneSymbolsObjs & geGeneSymbols
                Iterator<GeneSymbol> intersectionIter =  intersectionGS.iterator();
                while (intersectionIter.hasNext()) {
                    GeneSymbol geneSymbol = intersectionIter.next();
                    if (! pwgeneSymbolsObjs.contains(geneSymbol)) {
                        // remove from intersectionGS list
                        intersectionGS.remove(geneSymbol);
                    }
                }
            } else {  // simply add goGeneSymbols to intersectionGS
                intersectionGS.addAll(pwgeneSymbolsObjs );
            }
        }

        return intersectionGS;
    }
    */
    public static Set<GeneSymbol> getCommonGeneSymbols(Collection<GeneSymbol> geGeneSymbols, Collection<GeneSymbol> goGeneSymbolsObjs, Collection<GeneSymbol> pwgeneSymbolsObjs) {
        Set<GeneSymbol> finalResults = new HashSet<GeneSymbol>();

        Collection<IntersectionWrapper>  modifiedGeGeneSymbols = null;
        Collection<IntersectionWrapper>  modifiedGOGeneSymbols = null;
        Collection<IntersectionWrapper>  modifiedPWGeneSymbols = null;


        if (geGeneSymbols != null) {
            modifiedGeGeneSymbols = new ArrayList<IntersectionWrapper>();
            for (Iterator<GeneSymbol> iterator = geGeneSymbols.iterator(); iterator.hasNext();) {
                GeneSymbol geneSymbol = iterator.next();
                IntersectionWrapper obj = new IntersectionWrapper(geneSymbol);
                modifiedGeGeneSymbols.add(obj);
            }
        }
        if (goGeneSymbolsObjs != null) {
            modifiedGOGeneSymbols  = new ArrayList<IntersectionWrapper>();
            for (Iterator<GeneSymbol> iterator = goGeneSymbolsObjs.iterator(); iterator.hasNext();) {
                GeneSymbol geneSymbol = iterator.next();
                IntersectionWrapper obj = new IntersectionWrapper(geneSymbol);
                modifiedGOGeneSymbols.add(obj);
            }
        }
        if (pwgeneSymbolsObjs != null) {
            modifiedPWGeneSymbols = new ArrayList<IntersectionWrapper>();
            for (Iterator<GeneSymbol> iterator = pwgeneSymbolsObjs.iterator(); iterator.hasNext();) {
                GeneSymbol geneSymbol = iterator.next();
                IntersectionWrapper obj = new IntersectionWrapper(geneSymbol);
                modifiedPWGeneSymbols.add(obj);
            }
        }

        Set<IntersectionWrapper> commonObjs = IntersectionWrapper.getCommonObjects(modifiedGeGeneSymbols, modifiedGOGeneSymbols, modifiedPWGeneSymbols,
                                                    null, null);
        // now convert these commonObjs in to respective GeneSymbol objects
        Iterator<IntersectionWrapper> commonIter = commonObjs.iterator();
        while (commonIter.hasNext()) {
            IntersectionWrapper intersectionHelper = commonIter.next();
            finalResults.add((GeneSymbol)intersectionHelper.object);
        }

        return finalResults;
    }
    public static Collection<GeneSymbol> handleGeneIdentifiers(AnnotationCriteria annotCrit, Session session) {
        Collection<? extends GeneIdentifier> geneIdentifiers = annotCrit.getGeneIdentifiers();
        Iterator<? extends GeneIdentifier> o = geneIdentifiers.iterator();
        GeneIdentifier gi = o.next();
        Collection<GeneSymbol> geneSymbols = null;
        GeneIdentifierHandler handler = null;
        if (gi instanceof GeneSymbol) handler = new GeneIdentifierHandler.GeneSymbolHandler();
        else if (gi instanceof LocusLink) handler = new GeneIdentifierHandler.LocusLinkHandler();
        else if (gi instanceof GeneAccession ) handler = new GeneIdentifierHandler.GeneAccessionHandler();
        geneSymbols = handler.handle( geneIdentifiers, session);
        return geneSymbols;
    }

    /**
     *  This method converts a given set of GeneOntologyIDs into GeneSymbols
     * @param goIDs GOOntologyIDs
     * @param session
     * @return Returns a collection of GeneSymbol objects
     */
    public final static Collection<GeneSymbol> convertGOIDsToGeneSymbols(Collection<String> goIDs, Session session) {
        Criteria crit= session.createCriteria(GeneOntology.class);
        crit.add(Restrictions.in(GeneOntology.GO_ID, goIDs)).setProjection(
                    Property.forName(GeneOntology.GENE_SYMBOL));
        List<String> geneSymbols = crit.list();

        //convert these String to GeneSymbol objects
        Collection<GeneSymbol> geneSymbolObjs = new ArrayList<GeneSymbol>();

        for (int i = 0; i < geneSymbols.size(); i++) {
            GeneSymbol gs = new GeneSymbol(geneSymbols.get(i));
            geneSymbolObjs.add(gs);
        }

        return geneSymbolObjs ;
    }

    /**
     *  This method converts a given set of GeneAccessions into GeneSymbols
     * @param accessions numbers
     * @param session
     * @return Returns a collection of GeneSymbol objects
     */
    public final static Collection<GeneSymbol> retrieveGeneSymbolsForAccessios (Collection<GeneAccession> accessions, Session session) {

        Criteria crit= session.createCriteria(GeneAccession.class);
        crit.add(Restrictions.in(gov.nih.nci.cg.dataBeans.GeneAccession.ACCESSION, accessions)).setProjection(
                    Property.forName(gov.nih.nci.cg.dataBeans.GeneAccession.GENE_SYMBOL));
        List<String> geneSymbols = crit.list();

        //convert these String to GeneSymbol objects
        Collection<GeneSymbol> geneSymbolObjs = new ArrayList<GeneSymbol>();

        for (int i = 0; i < geneSymbols.size(); i++) {
            GeneSymbol gs = new GeneSymbol(geneSymbols.get(i));
            geneSymbolObjs.add(gs);
        }

        return geneSymbolObjs ;
    }

    /**
     *  This method converts a given set of GenePathways into GeneSymbols
     * @param pathways
     * @param session
     * @return Returns a collection of GeneSymbol objects
     */
    public final static Collection<GeneSymbol> convertPathwaysToGeneSymbols(Collection<String> pathways, Session session) {
        Criteria crit= session.createCriteria(GenePathway.class);
        crit.add(Restrictions.in(GenePathway.GENE_PATHWAY, pathways)).setProjection(
                    Property.forName(GeneOntology.GENE_SYMBOL));
        List<String> geneSymbols = crit.list();

        //convert these String to GeneSymbol objects
        Collection<GeneSymbol> geneSymbolObjs = new ArrayList<GeneSymbol>();

        for (int i = 0; i < geneSymbols.size(); i++) {
            GeneSymbol gs = new GeneSymbol(geneSymbols.get(i));
            geneSymbolObjs.add(gs);
        }
        return geneSymbolObjs ;
    }

}
