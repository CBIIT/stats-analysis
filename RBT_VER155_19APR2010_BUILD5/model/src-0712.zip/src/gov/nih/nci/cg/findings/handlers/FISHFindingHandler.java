package gov.nih.nci.cg.findings.handlers;

import gov.nih.nci.cg.findings.*;
import gov.nih.nci.cg.dto.SpecimenBasedFindingSearchCriteria;
import gov.nih.nci.cg.dto.FISHFindingSearchCriteria;
import gov.nih.nci.cg.dto.AnnotationCriteria;
import gov.nih.nci.cg.enums.OperatorType;

import java.util.*;

import org.hibernate.*;
import org.hibernate.criterion.Restrictions;
import org.hibernate.criterion.Expression;

/**
 * User: Ram Bhattaru <BR>
 * Date: Apr 4, 2006 <BR>
 * Version: 1.0 <BR>
 */
public class FISHFindingHandler extends SpecimenFindingHandler {
    protected Class getFindingType() {
        return FISHFinding.class;
    }

    protected StringBuffer handleMyFindingCrit(SpecimenBasedFindingSearchCriteria sc,
                                               HashMap params, Session session) {
        FISHFindingSearchCriteria fsc = (FISHFindingSearchCriteria ) sc;
        OperatorType annotOpType = fsc.getAnnotationCriteriaOpType();
        if (annotOpType == null) annotOpType = OperatorType.OR;  // default

        StringBuffer hSQL = buildTargetFindingHSQL();
        Set<GeneSymbol> allGeneSymbolsObjs = new HashSet();

        /*    1.BEGIN: HANDLE ANNOTATION CRITERIA
                Convert all annotations specified in the SearchCriteria to GeneSymbols and add to
                allGeneSymbolsObj
        */
        AnnotationCriteria annotCrit = fsc.getAnnotationCriteria();

        if (annotCrit != null) {
            AnnotationCriteriaHandler annotHandler = new AnnotationCriteriaHandler();
            Set<GeneSymbol> annotGeneSymbolsObjs = annotHandler.handle(annotCrit, session);
            /* if any of annotation dto is specified and still annotGeneSymbolsObjs  is empty
               that means no GeneSymbols were selected either because of AND'ing between Annotation crits
               or may be no bioMarker is present in any  of the specified AnnotationCriteria.  So
               in either of these cases simply return empty FISHFinding list */
            if (annotGeneSymbolsObjs.size() <= 0 && (annotOpType == OperatorType.AND) ) {
                return hSQL ;
            }
            allGeneSymbolsObjs.addAll(annotGeneSymbolsObjs);
        }


        /**2. HANDLE FISHFINDING CRITERIA ITSELF */
        // 2.1 Now handleMyFindingCrit BioMarkerCrieria (specified as GeneBiomarkerSearchCriteria)
        if (fsc.getBioMarkerCrit() != null) {
            Collection<GeneSymbol> queryGeneSybs = fsc.getBioMarkerCrit().getGeneSymbols();
            if ( queryGeneSybs != null && queryGeneSybs.size() > 0) {
                // apply annotOpType
                if (annotOpType == OperatorType.OR) // take union
                    allGeneSymbolsObjs.addAll(queryGeneSybs);
                else { // take intersection
                    Set<GeneSymbol> tmpGeneSymbolsObjs = allGeneSymbolsObjs;
                    allGeneSymbolsObjs = AnnotationCriteriaHandler.getCommonGeneSymbols(tmpGeneSymbolsObjs, queryGeneSybs, null);
                }
            }

        }

        // 2.2 Now convert these allGeneSymbolsObjs in to a list of GeneBasedBiomarkers so that be used in Hibernate Object Query
        if (allGeneSymbolsObjs.size() > 0) {
           String condition = (annotOpType == OperatorType.AND) ? " AND " : " OR ";
           hSQL.append( " f.geneBasedBiomarker IN (FROM GeneBasedBiomarker g WHERE g.geneSymbol IN (:bioMarkerList)) ");
           hSQL.append(condition);
           params.put("bioMarkerList", allGeneSymbolsObjs);

       /* TODO:  I am not sure if it is used
          Criteria findingCrit = session.createCriteria(FISHFinding.class);
           Criteria bioMarkerCrit = findingCrit.createCriteria(FISHFinding.GENE_BASED_BIOMARKER);
           bioMarkerCrit.add(Restrictions.in(GeneBasedBiomarker.GENE_SYMBOL, allGeneSymbolsObjs));
        */   /* TODO: List<GeneBasedBiomarker> biomarkerList = convertToBiomarkers(allGeneSymbolsObjs, session);
          if (biomarkerList.size() <= 0 ) {
              // means no biomarkers were retrived with the given gene symbols
              return findingCrit ;
          }
          findingCrit.add(Restrictions.in(FISHFinding.GENE_BASED_BIOMARKER, biomarkerList));
          TODO: */
        }

        // 3. Now add each of the other Object level dto basically AND'ing
        addFISHFindingCriteria(fsc, hSQL, params);

        return hSQL;
    }


    protected void initializeProxies(Collection<? extends SpecimenBasedMolecularFinding> findings) {
        Collection<FISHFinding> fishFindings = new ArrayList();
        for (Iterator iterator = findings.iterator(); iterator.hasNext();) {
            FISHFinding o =  (FISHFinding) iterator.next();
            GeneAnnotation geneAnnot = o.getGeneBasedBiomarker().getBioMarkerAnnotation();
            fishFindings.add(o);
        }
    }

    private void addRatioValueCrit(FISHFindingSearchCriteria.RatioValueCriteria r, StringBuffer hSQL, HashMap params) {
        OperatorType oper = r.getRatioOperator();

        /* this operator will be only one of GT/LT/EQ or else an exception would already have raised
            by the  setRatio() method of the FISHFindingSearchCriteria object  */


          switch(oper) {
                case GT: {
                   hSQL.append(" f.ratio > :ratio AND ");
                   break;
                }
                case LT: {
                    hSQL.append(" f.ratio < :ratio AND  ");
                    break;
                }
                case EQ: {
                    hSQL.append(" f.ratio = :ratio AND ");
                    break;
                }
                default: {
                    // this should never happen.  If happens simply ignore it
                }
            }
            // now set the ratio param for Hibernate query
            params.put("ratio", r.getRatio());
    }

    private void addRatioRangeValueCrit(FISHFindingSearchCriteria.RatioRangeValueCriteria r, StringBuffer hSQL, HashMap params) {
        hSQL.append( " f.ratio BETWEEN :lowerLimit AND :upperLimit AND ");
        //crit.add(Restrictions.between(FISHFinding.RATIO, r.getRatioLowerLimit(), r.getRatioUpperLimit()));
        params.put("lowerLimit", r.getRatioLowerLimit());
        params.put("upperLimit", r.getRatioUpperLimit());
    }

    private void addFISHFindingCriteria(FISHFindingSearchCriteria fsc, StringBuffer hSQL, HashMap params) {
        //Criteria findingCrit = session.createCriteria(FISHFinding.class);
        boolean critAdded = false;
        if (fsc.getCnaStatus() != null) {
            hSQL.append(" f.cnaStatus = :cnaSatus AND ");
            //q.setParameter("cnaSatus", fsc.getCnaStatus());
            params.put("cnaSatus", fsc.getCnaStatus());
            critAdded = true;
        }
        if (fsc.getReference() != null) {
            hSQL.append(" f.referenceName = :rName AND ");
            //q.setParameter("rName", fsc.getReference());
            params.put("rName", fsc.getReference());
            critAdded = true;
        }
        if (fsc.getRatioCrit() != null) {
            FISHFindingSearchCriteria.RatioCriteria c =  fsc.getRatioCrit();
            if (c instanceof FISHFindingSearchCriteria.RatioValueCriteria) {
                addRatioValueCrit((FISHFindingSearchCriteria.RatioValueCriteria)c, hSQL, params);
            } else {
                addRatioRangeValueCrit((FISHFindingSearchCriteria.RatioRangeValueCriteria)c, hSQL, params);
            }
        }
        //return findingCrit;
    }

    private List<GeneBasedBiomarker> convertToBiomarkers(Set<GeneSymbol> geneSymbols, Session session) {
        List<GeneBasedBiomarker> bioMarkerList = new ArrayList();
        if (geneSymbols != null && geneSymbols.size() > 0) {
            Criteria crit = session.createCriteria(GeneBasedBiomarker.class);
            crit.add(Expression.in(GeneBasedBiomarker.GENE_SYMBOL , geneSymbols));
            bioMarkerList = crit.list();
        }
        System.out.println("Total GeneBasedBiomarkers retrieved: " + bioMarkerList.size());
        return bioMarkerList;
    }

    /**
     * This method retrives all GeneAnnotations for the GeneSymbols passed in.  Then it will
     * return these Annotations as Map using GeneId (same as GeneSymbol) as key.
     * @param geneSymbols Set of unique GeneSymbols
     * @param session
     * @return Map using GeneId (same as GeneSymbol) as key
     */
//   /* public static Map<String, GeneAnnotation>  retriveGeneAnnotations(Set<GeneSymbol> geneSymbols, Session session) {
//
//        //convert GeneSymbols in o Strings
//        Collection<String> gss= new ArrayList<String>();
//        for (Iterator<GeneSymbol> iterator = geneSymbols.iterator(); iterator.hasNext();) {
//           GeneSymbol geneSymbol = iterator.next();
//           gss.add(geneSymbol.getValue());
//        }
//
//        /*** USING OUTER JOIN STRATEGY **********************
//        Criteria crit = session.createCriteria(GeneAnnotation.class).add(
//                        Restrictions.in(GeneAnnotation.ID, gss));
//        crit.setFetchMode(GeneAnnotation.GENE_ACCESIIONS, FetchMode.JOIN);
//        crit.setFetchMode(GeneAnnotation.GENE_ONTOLOGIES, FetchMode.JOIN);
//        crit.setFetchMode(GeneAnnotation.PATHWAYS, FetchMode.JOIN);
//        ******************************************************
//         HQL WAY:
//         Query q = session.createQuery(
//            "FROM GeneAnnotation  G  left join G.geneAccessions " +
//                    "left join G.pathways left join G.geneOntologyIDs " +
//                    "WHERE G.id IN  (:gss)");
//        q.setParameterList("gss", gss);
//        ******************************************************/
//
//        Criteria crit = session.createCriteria(GeneBasedBiomarker.class);
//        crit.add(Expression.in("geneSymbol", geneSymbols));
//        List<GeneAnnotation> populatedGeneAnnotList = crit.list();
//
//        Map<String, GeneAnnotation> map = new HashMap<String, GeneAnnotation>();
//        // Initialize Lazy Collections
//        for (Iterator<GeneAnnotation> iterator = populatedGeneAnnotList.iterator(); iterator.hasNext();) {
//            GeneAnnotation geneAnnotation = iterator.next();
//            Hibernate.initialize(geneAnnotation.getGeneAccessions());
//            Hibernate.initialize(geneAnnotation.getPathways());
//            Hibernate.initialize(geneAnnotation.getGeneOntologyIDs());
//
//            // now store these GeneAnnotations in a Map using GeneSymbol as key
//            map.put(geneAnnotation.getId(), geneAnnotation);
//        }
//        return map;
//    }

}
