package gov.nih.nci.cg.findings.handlers;

import gov.nih.nci.cg.findings.GeneSymbol;
import gov.nih.nci.cg.findings.GeneIdentifier;
import gov.nih.nci.cg.findings.GeneAnnotation;
import gov.nih.nci.cg.findings.GeneAccession;

import java.util.*;

import org.hibernate.Session;
import org.hibernate.Criteria;
import org.hibernate.criterion.Restrictions;
import org.hibernate.criterion.Property;

/**
 * User: Ram Bhattaru <BR>
 * Date: Apr 18, 2006 <BR>
 * Version: 1.0 <BR>
 */
public abstract class GeneIdentifierHandler {
     public abstract Collection<GeneSymbol> handle(Collection<? extends GeneIdentifier> geneIdentifiers, Session session);
     public final static class LocusLinkHandler extends GeneIdentifierHandler {
           public Collection<GeneSymbol> handle(Collection<? extends GeneIdentifier> geneIdentifiers, Session session) {
                   Criteria c = session.createCriteria(GeneAnnotation.class).add(
                   Restrictions.in(GeneAnnotation.LOCUS_LINK, geneIdentifiers)).setProjection(
                       Property.forName(GeneAnnotation.ID));
                   List<String> geneSymbols = c.list();
                    //convert these String to GeneSymbol objects
                   Collection<GeneSymbol> geneSymbolObjs = convertStringToGeneSymbols(geneSymbols);
                   return geneSymbolObjs ;
           }
     }
     public final static class GeneSymbolHandler extends GeneIdentifierHandler {
           public Collection<GeneSymbol> handle(Collection<? extends GeneIdentifier> geneIdentifiers, Session session) {
               Set<GeneSymbol> set = new HashSet<GeneSymbol>();
               for (Iterator<? extends GeneIdentifier> iterator = geneIdentifiers.iterator(); iterator.hasNext();) {
                   GeneSymbol geneSymbol =  (GeneSymbol)iterator.next();
                   set.add(geneSymbol);
               }
               return set;
           }
     }
     public final static class GeneAccessionHandler extends GeneIdentifierHandler {
           public Collection<GeneSymbol> handle(Collection<? extends GeneIdentifier> geneIdentifiers, Session session) {
               // first convert these GeneAccession in to Strings
               Set<String> set = new HashSet<String>();
               for (Iterator<? extends GeneIdentifier> iterator = geneIdentifiers.iterator(); iterator.hasNext();) {
                      set.add(iterator.next().getValue());
               }

               // then retrieve correponding geneSymbols as Strings
               Criteria crit= session.createCriteria(GeneAccession.class);
                crit.add(Restrictions.in(GeneAccession.VALUE, set)).setProjection(
                       Property.forName(GeneAccession.GENE_SYMBOL));
                List<String> geneSymbols = crit.list();

                //convert these String to GeneSymbol objects
               Collection<GeneSymbol> geneSymbolObjs = convertStringToGeneSymbols(geneSymbols);
               return geneSymbolObjs ;
        }
     }
     Collection<GeneSymbol> convertStringToGeneSymbols(List<String> geneSymbols) {
               Collection<GeneSymbol> geneSymbolObjs = new ArrayList<GeneSymbol>();
               for (int i = 0; i < geneSymbols.size(); i++) {
                   GeneSymbol gs = new GeneSymbol(geneSymbols.get(i));
                   geneSymbolObjs.add(gs);
               }
               return geneSymbolObjs;
           }
}
