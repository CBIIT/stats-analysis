package gov.nih.nci.cg.findings.handlers;

import gov.nih.nci.cg.findings.SpecimenBasedMolecularFinding;
import gov.nih.nci.cg.dto.SpecimenBasedFindingSearchCriteria;
import gov.nih.nci.cg.dto.StudyParticipantCriteria;
import gov.nih.nci.cg.dto.SpecimenCriteria;
import gov.nih.nci.cg.dto.PatientCriteria;
import gov.nih.nci.cg.enums.OperatorType;
import gov.nih.nci.cg.util.HibernateUtil;
import gov.nih.nci.cg.util.HQLHelper;

import java.util.*;
import java.text.MessageFormat;

import org.hibernate.Session;
import org.hibernate.Query;

/**
 * User: Ram Bhattaru <BR>
 * Date: Mar 19, 2006 <BR>
 * Version: 1.0 <BR>
 *
 * This class uses Template pattern in combination with Strategy pattern.  This class
 * is primarily responsible for all types of findings hence acts as a Controller to
 * persistence layer
 */
public abstract class SpecimenFindingHandler {
   public final String FINDING_ALIAS = "f";

       protected abstract StringBuffer handleMyFindingCrit(SpecimenBasedFindingSearchCriteria sc,
                                                           HashMap params, Session session);
   protected abstract Class getFindingType();
   protected abstract void initializeProxies(Collection<? extends SpecimenBasedMolecularFinding> findings);
    /**
     * At a high level gets hql for SpecimenFindingCriteria and StudyPartipcantCriteria and combines them and
     * execute whole query from StudyPartipcantHandler
     * Detailed steps are as below.
     * 1. It calls handleMyFindingCrit() method on the correponding subclass finding in which this code
     *    is executing.  This method adds required dto to Hibernate Criteria object (that
     *    includes handling of both AnnotationCriteria and Findings object dto itself)
     * 2. It then instantiates a StudyBasedCriteria handler (based on instance of StudyBasedCriteria)
     *    to handleMyFindingCrit StudyBasedCriteria and adding to the above finding dto.
     * 3. Then it executing the whole query to retrieve all subtype findings.
     *
     * @param sc This represents one subtype of SpecimenBasedFindingSearchCriteria
     * @return Collection of one of sub types of SpecimenBasedMolecularFinding corresponding to the
     *          SpecimenBasedFindingSearchCriteria passed in.
     */

    public Collection<? extends SpecimenBasedMolecularFinding> getFindings(SpecimenBasedFindingSearchCriteria sc) {
        Collection findings = null;
        Set<? extends SpecimenBasedMolecularFinding> results = new HashSet();
        StudyParticipantCriteria studyCrit = sc.getStudyParticipantCriteria();
        OperatorType opType = sc.getStudyParticipantCriteriaOpType();
        if (opType == null) opType = OperatorType.AND; // default to AND

        Session session = HibernateUtil.getSession();
        HibernateUtil.beginTransaction();

        HashMap params = new HashMap();

        /* 1. prepare hSQL required to for handling corresponding subtype type finding */
        StringBuffer hSQL = handleMyFindingCrit(sc, params, session);

        if (studyCrit == null) {
            if (params.isEmpty()) {
                // means Annotation dto did not pass
                session.close();
                return results;
            }

            // remove any trailing AND / OR
            String interHSQL = HQLHelper.removeTrailingToken(hSQL, "AND");
            String finalHSQL = HQLHelper.removeTrailingToken(new StringBuffer(interHSQL), "OR");

            Query q = session.createQuery(finalHSQL);
            HQLHelper.setParamsOnQuery(params, q);
            Collection objs = q.list();
            initializeProxies(objs);

            results.addAll(objs);
            session.close();
            return results;
        }

        /* 2.  instantiates a StudyBasedCriteria handler (based on instance of StudyBasedCriteria)*/
        StudyParticipantHandler handler = getStudyPartcipantHandler(studyCrit);

        /* 3. executing the whole query to retrieve all subtype findings (by calling searchFindings()*/
        if (handler != null) {
            findings = handler.searchFindings(studyCrit, opType, getFindingType(), hSQL, params, session);
            if (findings != null) {
                initializeProxies(findings);
                results.addAll(findings);
            }
        }
        session.close();
        return results;
     }

    protected StringBuffer buildTargetFindingHSQL() {
         String targetHSQL = new String(" FROM {0} {1} LEFT JOIN FETCH {2}.specimen " +
                                  " LEFT JOIN FETCH {3}.specimen.studyParticipant WHERE ");
             return new StringBuffer(MessageFormat.format(targetHSQL, new Object[]
                                 {getFindingType().getName(), FINDING_ALIAS, FINDING_ALIAS, FINDING_ALIAS}));
     }

    private StudyParticipantHandler getStudyPartcipantHandler(StudyParticipantCriteria studyCrit) {
        StudyParticipantHandler handler = null;
        if (studyCrit instanceof SpecimenCriteria )  {
            handler = new StudyParticipantHandler.SpecimenHandler();
        } else if (studyCrit instanceof PatientCriteria) {
                handler = new StudyParticipantHandler.PatientHandler();
        } // else if HistologyCriteria etc
        return handler;
    }


}
