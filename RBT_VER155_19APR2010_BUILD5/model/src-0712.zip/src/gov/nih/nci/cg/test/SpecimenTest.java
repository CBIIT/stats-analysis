package gov.nih.nci.cg.test;

import junit.framework.TestCase;
import gov.nih.nci.cg.dto.SpecimenCriteria;
import gov.nih.nci.cg.dto.FISHFindingSearchCriteria;
import gov.nih.nci.cg.findings.SpecimenBasedMolecularFinding;
import gov.nih.nci.cg.findings.FindingsManager;
import gov.nih.nci.cg.enums.OperatorType;

import java.util.Collection;
import java.util.ArrayList;

/**
 * User: Ram Bhattaru <BR>
 * Date: Apr 24, 2006 <BR>
 * Version: 1.0 <BR>
 */
public class SpecimenTest extends TestCase {
    SpecimenCriteria sc;
    FISHFindingSearchCriteria  fishSC;
    protected void setUp() throws Exception {
        super.setUp();

    }

    private void setSpecimenCriteria() {
        SpecimenCriteria sc = new SpecimenCriteria();
        Collection<String>specimenIDs = new ArrayList<String>();
        specimenIDs.add("215148");
        sc.setSpecimenIDs(specimenIDs);
        fishSC.setStudyParticipantCriteria(sc);
        fishSC.setStudyParticipantCriteriaOpType(OperatorType.AND);
    }

    public void testSpecimenCriteria() {
        setSpecimenCriteria();

    }
    private void executeSearch() {
        Collection<? extends SpecimenBasedMolecularFinding> findings = FindingsManager.getFindings(fishSC);
      //  for (Iterator<? extends SpecimenBasedMolecularFinding> iterator = findings.iterator(); iterator.hasNext();) {
    }
}
